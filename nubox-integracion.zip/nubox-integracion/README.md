# Bienvenido al plugin de Nubox para WooCommerce


[Descargar el plugin](https://github.com/Aplicaciones-Web-Chile/woo-nubox/archive/refs/heads/main.zip)

***


¿Tienes un sitio web que funciona con Woocomerce y quieres emitir tus documentos automáticamente con Nubox?
Sigue estos simples pasos y en unos minutos tendrás integrado tu e-commerce con tu sistema de facturación.

* Crea tu cuenta en [integraciones.nubox.com](https://integraciones.nubox.com/)
* Activa el servicio "WooCommerce".
* Una vez activado, genera tu API KEY
* [Descarga el plugin oficial](https://github.com/Aplicaciones-Web-Chile/woo-nubox/archive/refs/heads/main.zip) e instálalo en tu sitio web
* Dentro del menú izquierdo "Woocommerce" -> "Configuración de Nubox" agrega tus credenciales y ya estarás conectado con nuestros servicios.



